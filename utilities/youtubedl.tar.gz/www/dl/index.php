<?php

// check we are logged in




?>









<html>
<head>
<title>youtube-dl</title>
<style>
body{
	background-color:#708890;
	font-family:Arial;
	color:white;
}



</style>
</head>
<body>
<center>









<h1>youtube download</h1>

<?php
// <p>Paste the URL below, and press GO.</p>
?>










<form action="dl.php" method="post">


<label for="username">user:</label>
<select name="username" id="username">
  <option value="word">word</option>
</select>


<label for="dltype">dltype:</label>
<select name="dltype" id="dltype">
  <option value="audio-both">audio-both</option>
  <option value="audio-mp3">audio-mp3</option>
  <option value="audio-video">audio-video</option>
  <option value="video">video</option>
</select>

URL: <input type="text" name="url">





<input type="submit" value="GO">
</form>







<form action="dl.php" method="post">


<label for="username">user:</label>
<select name="username" id="username">
  <option value="emma">emma</option>
</select>







<label for="dltype">dltype:</label>
<select name="dltype" id="dltype">
  <option value="audio-both">audio-both</option>
  <option value="audio-mp3">audio-mp3</option>
  <option value="audio-video">audio-video</option>
  <option value="video">video</option>
</select>

URL: <input type="text" name="url">



<input type="submit" value="GO">
</form>








<form action="dl.php" method="post">


<label for="michelle">user:</label>
<select name="username" id="username">
  <option value="michelle">michelle</option>
</select>


<label for="dltype">dltype:</label>
<select name="dltype" id="dltype">
  <option value="audio-both">audio-both</option>
  <option value="audio-mp3">audio-mp3</option>
  <option value="audio-video">audio-video</option>
  <option value="video">video</option>
</select>

URL: <input type="text" name="url">



<input type="submit" value="GO">
</form>










</body>
</html>









<?php








// $weare = "http://" $_SERVER['SERVER_ADDR']
// $weare = $_SERVER['SERVER_ADDR'] . $_SERVER['REMOTE_PORT'] . $_SERVER['PHP_SELF']
//echo "$weare";





// $stdoud = "/tmp/.dl.sh.stoud";
// if (file_exists($stdoud)) {
//	echo "<p>";
//	$outputt = shell_exec("tail -c90 $stdoud 2>/dev/null | grep -v 'pass \-k to keep' | grep -v 'Extracting information' | cut -d'[' -f2 | tr -s ']' ' '");
//	echo $outputt;
//	echo "</p>";
//}





	// echo "################ inprogress";
	//$outputt = shell_exec("tail -n1 $stdoud 2>/dev/null");
	
	
	
	
	
	
	//              $outputt = shell_exec("cat $stdoud 2>/dev/null | tail -n1");
	// $outputt = shell_exec("echo '' > $stdoud");
	// $outputt = shell_exec("tail -n1 $stdoud 2>/dev/null");
	



	// $outputt = shell_exec("echo '' > $stdoud");
	// $outputt = shell_exec("tail -c90 $stdoud 2>/dev/null | cut -d'[' -f2 | tr -s ']' ' '");		
	// $outputt = shell_exec("tail -c90 $stdoud 2>/dev/null | grep -v 'pass \-k to keep' | cut -d'[' -f2 | tr -s ']' ' '");
	#$outputt = shell_exec("tail -c90 $stdoud 2>/dev/null | grep -v 'pass \-k to keep' | grep -v 'Extracting information' | cut -d'[' -f2 | tr -s ']' ' '");
	





	echo "<textarea rows='3' cols='135'>";

	$outputy = shell_exec("/bin/dl.sh -P 2>/dev/null");		
	// echo "<p>";
	echo $outputy;
	// echo "</p>";
	//<br>

	echo "</textarea>";






	echo "<textarea rows='12' cols='135'>";



	$outputt = shell_exec("/bin/dl.sh printhistory");
	echo $outputt;
	//echo "</p>";

	echo "</textarea>";





?>

<?php





// $dllog = "/tmp/dllog.txt";
// if (file_exists($dllog)) {
//	$output = shell_exec("tail -n10 $dllog 2>/dev/null");
//	echo "<textarea rows='12' cols='135'>";
//	echo $output;
//	echo "</textarea>";
//}
	// echo "################ completed";








echo "<p>";
//echo "c_id:" . $_SERVER['REMOTE_ADDR'];
$outputI = $_SERVER['REMOTE_ADDR'];
$outputD = shell_exec("date +%Y%m%d%H%M 2>/dev/null | cut -d':' -f1,2 | sed 's!:!!g' | head -c 11");
echo $outputI . "_" . $outputD;
echo "</p>";


// $outputI = shell_exec("echo $REMOTE_ADDR 2>/dev/null | sed 's!\.!!g' | sed 's!::!!g'");
// $outputI = shell_exec("echo $['REMOTE_ADDR'] 2>/dev/null | sed 's!\.!!g' | sed 's!::!!g'");
// $outputI = shell_exec("echo " . $REMOTE_ADDR . "2>/dev/null | sed 's!\.!!g' | sed 's!::!!g'");
// $outputI = shell_exec("echo " . $_SERVER['REMOTE_ADDR'] . "2>/dev/null | sed 's!\.!!g' | sed 's!::!!g'");
// $outputI = shell_exec("echo " . $_SERVER['REMOTE_ADDR'] . " 2>/dev/null | sed 's!\.!!g' | sed 's!::!!g' | sed 's! !!g'");
#$outputI = shell_exec("echo " . $_SERVER['REMOTE_ADDR'] . " 2>/dev/null | sed 's!\.!!g' | sed 's!::!!g' | sed 's! !!g'");
// $outputI = shell_exec("echo " . $_SERVER['REMOTE_ADDR'] . " 2>/dev/null | sed 's!\.!!g' | sed 's!::!!g' | tr -d ' '");


// $outputI = shell_exec("echo " . $_SERVER['REMOTE_ADDR'] . " 2>/dev/null | sed 's!\.!!g' | sed 's!::!!g'");
// $outputD = shell_exec("date +%Y%m%d%H%M 2>/dev/null | cut -d':' -f1,2 | sed 's!:!!g' | head -c 11");
// echo $outputI . "_" . $outputD;
// echo $outputD;








// $outputD = shell_exec("date +%T 2>/dev/null");
// echo $outputD;
// $outputD = shell_exec("date +%T 2>/dev/null | cut -d':' -f1,2 | sed 's!:!!g' | head -c 3");











// phpinfo();


?>



